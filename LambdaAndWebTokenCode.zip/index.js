const doc = require('dynamodb-doc');

const dynamo = new doc.DynamoDB();

var jwt = require('jsonwebtoken');
var request = require('request');
var jwkToPem = require('jwk-to-pem');

/**
 * Provide an event that contains the following keys:
 *
 *   - operation: one of the operations in the switch statement below
 *   - tableName: required for operations that interact with DynamoDB
 *   - payload: a parameter to pass to the operation being performed
 */
exports.handler = (event, context, callback) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));

    console.log("---------------Context:"+JSON.stringify(context, null, 2));
    console.log("---------------Event:"+JSON.stringify(event, null, 2));
    
    var token = event.params.header.Authorization;
    var decodedJwt = jwt.decode(token, {complete: true});
    console.log("---------------Token:"+JSON.stringify(decodedJwt, null, 2));

    const operation = event["body-json"].operation;
    const payload = event["body-json"].payload;

    if (event["body-json"].tableName) {
        payload.TableName = event["body-json"].tableName;
    }

    switch (operation) {
        case 'create':
            dynamo.putItem(payload, callback);
            break;
        case 'read':
            dynamo.getItem(payload, callback);
            break;
        case 'update':
            dynamo.updateItem(payload, callback);
            break;
        case 'delete':
            dynamo.deleteItem(payload, callback);
            break;
        case 'list':
            dynamo.scan(payload, callback);
            break;
        case 'echo':
            callback(null, payload);
            break;
        case 'ping':
            callback(null, 'pong');
            break;
        default:
            callback(new Error(`Unrecognized operation "${operation}"`));
    }
};
